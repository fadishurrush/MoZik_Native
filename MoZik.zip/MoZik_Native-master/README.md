# MoZik_Native

Register/Edit Profile: image 

Fragment categories: check anghami

Forgot password

Design enhamcements: color palette, use of images

Navigation Bar in Home Activity
